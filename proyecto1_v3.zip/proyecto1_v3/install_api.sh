#!/bin/bash
# Amazon Linux 2023 - Instalar Flask API (IoT Orders)

sudo dnf update -y
sudo dnf install -y python3 python3-pip

pip3 install flask psycopg2-binary pika

# Escribir la aplicación Flask
cat <<'EOF' > /opt/api.py
import os, uuid, json
import pika, psycopg2
from flask import Flask, request, jsonify

app = Flask(__name__)

DB_HOST     = os.environ.get("DB_HOST", "localhost")
DB_NAME     = os.environ.get("DB_NAME", "iot_db")
DB_USER     = os.environ.get("DB_USER", "iotuser")
DB_PASSWORD = os.environ.get("DB_PASSWORD", "password123")
MQ_HOST     = os.environ.get("MQ_HOST", "localhost")
MQ_USER     = os.environ.get("MQ_USER", "admin")
MQ_PASSWORD = os.environ.get("MQ_PASSWORD", "password123")

def get_db():
    return psycopg2.connect(
        host=DB_HOST, database=DB_NAME,
        user=DB_USER, password=DB_PASSWORD)

def publish(routing_key, message):
    creds = pika.PlainCredentials(MQ_USER, MQ_PASSWORD)
    conn  = pika.BlockingConnection(pika.ConnectionParameters(host=MQ_HOST, credentials=creds))
    ch = conn.channel()
    ch.exchange_declare(exchange='orders', exchange_type='direct')
    ch.basic_publish(exchange='orders', routing_key=routing_key,
                     body=json.dumps(message),
                     properties=pika.BasicProperties(delivery_mode=2))
    conn.close()

@app.route('/orders', methods=['POST'])
def create_order():
    data = request.json.get('data', '') if request.json else ''
    task_id = str(uuid.uuid4())
    conn = get_db(); cur = conn.cursor()
    cur.execute("INSERT INTO tasks (task_id, operation, status) VALUES (%s,%s,%s)", (task_id,'POST','pending'))
    conn.commit(); cur.close(); conn.close()
    publish('post', {'task_id': task_id, 'data': data})
    return jsonify({'task_id': task_id}), 202

@app.route('/tasks/<task_id>', methods=['GET'])
def get_task(task_id):
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT task_id, operation, status, created_at FROM tasks WHERE task_id=%s", (task_id,))
    row = cur.fetchone(); cur.close(); conn.close()
    if not row: return jsonify({'error': 'Not found'}), 404
    return jsonify({'task_id': str(row[0]), 'operation': row[1], 'status': row[2], 'created_at': str(row[3])})

@app.route('/orders', methods=['GET'])
def get_orders():
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT order_id, data, task_id, created_at FROM orders ORDER BY order_id")
    rows = cur.fetchall(); cur.close(); conn.close()
    return jsonify([{'order_id': r[0], 'data': r[1], 'task_id': str(r[2]), 'created_at': str(r[3])} for r in rows])

@app.route('/orders/<int:oid>', methods=['PUT'])
def update_order(oid):
    data = request.json.get('data', '') if request.json else ''
    conn = get_db(); cur = conn.cursor()
    cur.execute("UPDATE orders SET data=%s WHERE order_id=%s RETURNING order_id", (data, oid))
    u = cur.fetchone(); conn.commit(); cur.close(); conn.close()
    if not u: return jsonify({'error': 'Not found'}), 404
    return jsonify({'order_id': oid, 'data': data, 'status': 'updated'})

@app.route('/orders/<int:oid>', methods=['DELETE'])
def delete_order(oid):
    task_id = str(uuid.uuid4())
    conn = get_db(); cur = conn.cursor()
    cur.execute("INSERT INTO tasks (task_id, operation, status) VALUES (%s,%s,%s)", (task_id,'DELETE','pending'))
    conn.commit(); cur.close(); conn.close()
    publish('delete', {'task_id': task_id, 'order_id': oid})
    return jsonify({'task_id': task_id}), 202

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
EOF

# Obtener IPs desde SSM Parameter Store
pip3 install boto3

cat <<'GETTER' > /opt/get_parameter.py
import boto3
from botocore.exceptions import ClientError

def get_ssm_parameter(name: str, default: str = None) -> str:
    client = boto3.client("ssm", region_name="us-east-1")
    try:
        response = client.get_parameter(Name=name)
        return response["Parameter"]["Value"]
    except ClientError as e:
        if e.response["Error"]["Code"] == "ParameterNotFound":
            print(f"[WARN] Parámetro '{name}' no encontrado. Usando valor por defecto: '{default}'")
            return default
        raise

if __name__ == "__main__":
    db_host = get_ssm_parameter("/iot/dev/postgres/public_ip", "localhost")
    mq_host = get_ssm_parameter("/iot/dev/rabbitmq/public_ip", "localhost")
    print(f"DB_HOST={db_host}")
    print(f"MQ_HOST={mq_host}")
GETTER

# Systemd service
DB_HOST=$(python3 /opt/get_parameter.py 2>/dev/null | grep DB_HOST | cut -d= -f2)
MQ_HOST=$(python3 /opt/get_parameter.py 2>/dev/null | grep MQ_HOST | cut -d= -f2)

cat <<ENV > /etc/systemd/system/api.service
[Unit]
Description=IoT Flask API
After=network.target

[Service]
Environment=DB_HOST=${DB_HOST:-localhost}
Environment=DB_NAME=iot_db
Environment=DB_USER=iotuser
Environment=DB_PASSWORD=password123
Environment=MQ_HOST=${MQ_HOST:-localhost}
Environment=MQ_USER=admin
Environment=MQ_PASSWORD=password123
ExecStart=/usr/bin/python3 /opt/api.py
Restart=always

[Install]
WantedBy=multi-user.target
ENV

systemctl daemon-reload
systemctl enable --now api
