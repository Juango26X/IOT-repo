#!/bin/bash
# Amazon Linux 2023 - Consumer DELETE (IoT Orders)

sudo dnf update -y
sudo dnf install -y python3 python3-pip

pip3 install psycopg2-binary pika boto3

# Obtener IPs desde SSM Parameter Store
cat <<'GETTER' > /opt/get_parameter.py
import boto3
from botocore.exceptions import ClientError

def get_ssm_parameter(name: str, default: str = None) -> str:
    client = boto3.client("ssm", region_name="us-east-1")
    try:
        response = client.get_parameter(Name=name)
        return response["Parameter"]["Value"]
    except ClientError as e:
        if e.response["Error"]["Code"] == "ParameterNotFound":
            print(f"[WARN] Parámetro '{name}' no encontrado. Usando valor por defecto: '{default}'")
            return default
        raise

if __name__ == "__main__":
    db_host = get_ssm_parameter("/iot/dev/postgres/public_ip", "localhost")
    mq_host = get_ssm_parameter("/iot/dev/rabbitmq/public_ip", "localhost")
    print(f"DB_HOST={db_host}")
    print(f"MQ_HOST={mq_host}")
GETTER

# Escribir el consumer
cat <<'EOF' > /opt/consumer_delete.py
import os, json, time
import pika, psycopg2

DB_HOST     = os.environ.get("DB_HOST", "localhost")
DB_NAME     = os.environ.get("DB_NAME", "iot_db")
DB_USER     = os.environ.get("DB_USER", "iotuser")
DB_PASSWORD = os.environ.get("DB_PASSWORD", "password123")
MQ_HOST     = os.environ.get("MQ_HOST", "localhost")
MQ_USER     = os.environ.get("MQ_USER", "admin")
MQ_PASSWORD = os.environ.get("MQ_PASSWORD", "password123")

def get_db():
    return psycopg2.connect(
        host=DB_HOST, database=DB_NAME,
        user=DB_USER, password=DB_PASSWORD)

def callback(ch, method, properties, body):
    msg = json.loads(body.decode())
    task_id, order_id = msg['task_id'], msg['order_id']
    conn = get_db(); cur = conn.cursor()
    cur.execute("UPDATE tasks SET status='processing' WHERE task_id=%s", (task_id,))
    conn.commit()
    time.sleep(2)
    cur.execute("DELETE FROM orders WHERE order_id=%s RETURNING order_id", (order_id,))
    deleted = cur.fetchone()
    status = 'completed' if deleted else 'failed'
    cur.execute("UPDATE tasks SET status=%s WHERE task_id=%s", (status, task_id))
    conn.commit(); cur.close(); conn.close()
    print(f"[consumer_delete] Task {task_id} -> {status}")
    ch.basic_ack(delivery_tag=method.delivery_tag)

creds = pika.PlainCredentials(MQ_USER, MQ_PASSWORD)
conn  = pika.BlockingConnection(pika.ConnectionParameters(host=MQ_HOST, credentials=creds))
ch = conn.channel()
ch.exchange_declare(exchange='orders', exchange_type='direct')
ch.queue_declare(queue='delete_queue', durable=True)
ch.queue_bind(exchange='orders', queue='delete_queue', routing_key='delete')
ch.basic_qos(prefetch_count=1)
ch.basic_consume(queue='delete_queue', on_message_callback=callback)
print('[*] consumer_delete esperando...')
ch.start_consuming()
EOF

# Obtener IPs y crear el servicio
DB_HOST=$(python3 /opt/get_parameter.py 2>/dev/null | grep DB_HOST | cut -d= -f2)
MQ_HOST=$(python3 /opt/get_parameter.py 2>/dev/null | grep MQ_HOST | cut -d= -f2)

cat <<ENV > /etc/systemd/system/consumer_delete.service
[Unit]
Description=IoT Consumer DELETE
After=network.target

[Service]
Environment=DB_HOST=${DB_HOST:-localhost}
Environment=DB_NAME=iot_db
Environment=DB_USER=iotuser
Environment=DB_PASSWORD=password123
Environment=MQ_HOST=${MQ_HOST:-localhost}
Environment=MQ_USER=admin
Environment=MQ_PASSWORD=password123
ExecStart=/usr/bin/python3 /opt/consumer_delete.py
Restart=always

[Install]
WantedBy=multi-user.target
ENV

systemctl daemon-reload
systemctl enable --now consumer_delete
