#!/bin/bash
# Amazon Linux 2023 - Producer de eventos sintéticos (IoT Orders)

sudo dnf update -y
sudo dnf install -y python3 python3-pip

pip3 install requests boto3

# Obtener IP de la API desde SSM Parameter Store
cat <<'GETTER' > /opt/get_parameter.py
import boto3
from botocore.exceptions import ClientError

def get_ssm_parameter(name: str, default: str = None) -> str:
    client = boto3.client("ssm", region_name="us-east-1")
    try:
        response = client.get_parameter(Name=name)
        return response["Parameter"]["Value"]
    except ClientError as e:
        if e.response["Error"]["Code"] == "ParameterNotFound":
            print(f"[WARN] Parámetro '{name}' no encontrado. Usando valor por defecto: '{default}'")
            return default
        raise

if __name__ == "__main__":
    api_ip = get_ssm_parameter("/iot/dev/api/public_ip", "localhost")
    print(f"API_IP={api_ip}")
GETTER

# Escribir el producer
cat <<'EOF' > /opt/producer.py
import os, time, random, requests, json

API_URL = os.environ.get("API_URL", "http://localhost:5000")

def esperar_api():
    for i in range(30):
        try:
            requests.get(f"{API_URL}/orders", timeout=3)
            print("[Productor] API lista!")
            return True
        except:
            print(f"[Productor] Esperando API... {i+1}/30")
            time.sleep(5)
    return False

def main():
    if not esperar_api():
        return

    task_ids = []

    # Crear 5 órdenes
    for i in range(5):
        data = f"Sensor #{i+1} - {random.uniform(20,35):.1f}C"
        r = requests.post(f"{API_URL}/orders", json={'data': data})
        if r.status_code == 202:
            tid = r.json()['task_id']
            task_ids.append(tid)
            print(f"  POST enviado -> TaskId: {tid[:8]}...")
        time.sleep(1)

    time.sleep(6)

    # Consultar estado de las tareas
    for tid in task_ids:
        r = requests.get(f"{API_URL}/tasks/{tid}")
        if r.status_code == 200:
            t = r.json()
            print(f"  Task {t['task_id'][:8]}... -> {t['status']}")

    # Ver órdenes
    r = requests.get(f"{API_URL}/orders")
    orders = r.json() if r.status_code == 200 else []
    print(f"  Total órdenes: {len(orders)}")

    # Eliminar primera orden
    if orders:
        oid = orders[0]['order_id']
        r = requests.delete(f"{API_URL}/orders/{oid}")
        print(f"  DELETE orden #{oid} -> {r.json()['task_id'][:8]}...")

    print("[Productor] Listo!")

if __name__ == '__main__':
    main()
EOF

# Obtener IP de la API y crear el servicio
API_IP=$(python3 /opt/get_parameter.py 2>/dev/null | grep API_IP | cut -d= -f2)

cat <<ENV > /etc/systemd/system/producer.service
[Unit]
Description=IoT Producer
After=network.target

[Service]
Environment=API_URL=http://${API_IP:-localhost}:5000
ExecStart=/usr/bin/python3 /opt/producer.py
Restart=no

[Install]
WantedBy=multi-user.target
ENV

systemctl daemon-reload
systemctl enable --now producer
