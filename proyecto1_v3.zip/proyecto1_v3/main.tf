# 1. RabbitMQ EC2
resource "aws_instance" "rabbitmq" {
  ami                    = var.ami_id
  instance_type          = var.instance_type
  key_name               = var.key_name
  subnet_id              = data.aws_subnets.default.ids[0]
  vpc_security_group_ids = [aws_security_group.rabbitmq_sg.id]
  user_data              = file("${path.module}/install_rabbitmq.sh")

  tags = {
    Name = "iot-rabbitmq"
    Role = "MessageBroker"
  }
}

# 2. PostgreSQL EC2
resource "aws_instance" "postgres" {
  ami                    = var.ami_id
  instance_type          = var.instance_type
  key_name               = var.key_name
  subnet_id              = data.aws_subnets.default.ids[0]
  vpc_security_group_ids = [aws_security_group.postgres_sg.id]
  user_data              = file("${path.module}/install_postgres.sh")

  tags = {
    Name = "iot-postgres"
    Role = "Database"
  }
}

# 3. API REST (Flask) EC2
resource "aws_instance" "api" {
  ami                    = var.ami_id
  instance_type          = var.instance_type
  key_name               = var.key_name
  subnet_id              = data.aws_subnets.default.ids[0]
  vpc_security_group_ids = [aws_security_group.api_sg.id]
  user_data              = file("${path.module}/install_api.sh")

  tags = {
    Name = "iot-api"
    Role = "BackendAPI"
  }
}

# 4. Consumer POST EC2
resource "aws_instance" "consumer_post" {
  ami                    = var.ami_id
  instance_type          = var.instance_type
  key_name               = var.key_name
  subnet_id              = data.aws_subnets.default.ids[0]
  vpc_security_group_ids = [aws_security_group.consumer_post_sg.id]
  user_data              = file("${path.module}/install_consumer_post.sh")

  tags = {
    Name = "iot-consumer-post"
    Role = "AsyncWorker"
  }
}

# 5. Consumer DELETE EC2
resource "aws_instance" "consumer_delete" {
  ami                    = var.ami_id
  instance_type          = var.instance_type
  key_name               = var.key_name
  subnet_id              = data.aws_subnets.default.ids[0]
  vpc_security_group_ids = [aws_security_group.consumer_delete_sg.id]
  user_data              = file("${path.module}/install_consumer_delete.sh")

  tags = {
    Name = "iot-consumer-delete"
    Role = "AsyncWorker"
  }
}

# 6. Producer EC2
resource "aws_instance" "producer" {
  ami                    = var.ami_id
  instance_type          = var.instance_type
  key_name               = var.key_name
  subnet_id              = data.aws_subnets.default.ids[0]
  vpc_security_group_ids = [aws_security_group.producer_sg.id]
  user_data              = file("${path.module}/install_producer.sh")

  tags = {
    Name = "iot-producer"
    Role = "EventProducer"
  }
}

# ==========================================
# AWS Systems Manager Parameter Store
# ==========================================
resource "aws_ssm_parameter" "rabbitmq_ip" {
  name        = "/iot/dev/rabbitmq/public_ip"
  type        = "String"
  value       = aws_instance.rabbitmq.public_ip
  description = "Public IP for RabbitMQ Server"
}

resource "aws_ssm_parameter" "postgres_ip" {
  name        = "/iot/dev/postgres/public_ip"
  type        = "String"
  value       = aws_instance.postgres.public_ip
  description = "Public IP for PostgreSQL Server"
}

resource "aws_ssm_parameter" "api_ip" {
  name        = "/iot/dev/api/public_ip"
  type        = "String"
  value       = aws_instance.api.public_ip
  description = "Public IP for API Server"
}

resource "aws_ssm_parameter" "consumer_post_ip" {
  name        = "/iot/dev/consumer-post/public_ip"
  type        = "String"
  value       = aws_instance.consumer_post.public_ip
  description = "Public IP for Consumer POST Server"
}

resource "aws_ssm_parameter" "consumer_delete_ip" {
  name        = "/iot/dev/consumer-delete/public_ip"
  type        = "String"
  value       = aws_instance.consumer_delete.public_ip
  description = "Public IP for Consumer DELETE Server"
}

resource "aws_ssm_parameter" "producer_ip" {
  name        = "/iot/dev/producer/public_ip"
  type        = "String"
  value       = aws_instance.producer.public_ip
  description = "Public IP for Producer Server"
}
